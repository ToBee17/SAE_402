let state = 0;
let life = 3;
let distance;
let piece = 0;
let jump = 0;
isPressed = false;

let vitesse = 6;
let variateur_vitesse = 500;
let vitessePlayer = vitesse;

let ent = 50;
let variateur = 5;

let ent_2 = 100;
let variateur_2 = 5;

let variateur_obstacle = 500;

let tabObstacle = [];
let tabOiseau = [];
let tabPiece = [];
let tabFloor = [];

let map = 0;
let Pmap = false;
let VarObstacle = true;
let Varlife = false;
let timer = 70;
let debugSound = true;
let megaTimer = 500;

let zoomFactor = 1;

function preload() {
	// load image
	spriteImage = loadImage("assets/sprite/galette.png");
	bonusImage = loadImage("assets/sprite/couronne.png");
	oiseauImage = loadImage("assets/sprite/oiseau.png");
	renardImage = loadImage("assets/sprite/renard.png");
	lifebarImage = loadImage("assets/sprite/lifebar.png");
	bouclierImage = loadImage("assets/sprite/bouclier.png");

	bg_game = loadImage("assets/bg_game.png");
	bg_start = loadImage("assets/bg_start.png");
	bg_end = loadImage("assets/bg_end.png");
	tutoImage = loadImage("assets/keyboard.png");

	
	sol_1 = loadImage("assets/sol/sol_1.png");
	sol_2 = loadImage("assets/sol/sol_trou.png");
	sol_3 = loadImage("assets/sol/sol_left.png");
	sol_4 = loadImage("assets/sol/sol_right.png");

	caillou_2 = loadImage("assets/obstacle/caillou_2.png");
	caillou_4 = loadImage("assets/obstacle/caillou_4.png");

	// load font
	font = loadFont("assets/font/retro_gaming.ttf");

	// load sound
	soundFormats('mp3', 'ogg');
	fondSound = loadSound("assets/sound/fond.mp3");
	breakSound = loadSound("assets/sound/break.mp3");
	jumpSound = loadSound("assets/sound/jump.mp3");
	shieldSound = loadSound("assets/sound/shield.mp3"); 
	eatSound = loadSound("assets/sound/eat.mp3");
	coinSound = loadSound("assets/sound/coin.mp3");
}

function setup() {
	createCanvas(windowWidth, windowHeight);
  
	// Calculer le facteur de zoom en fonction de la résolution de l'écran (Merci CHAT GPT)
	let baseWidth = 1920; // Largeur de référence pour le calcul du zoom
	let baseHeight = 1080; // Hauteur de référence pour le calcul du zoom
	let screenWidthFactor = windowWidth / baseWidth;
	let screenHeightFactor = windowHeight / baseHeight;
	zoomFactor = min(screenWidthFactor, screenHeightFactor); // Utiliser le facteur le plus petit pour garder l'aspect ratio
	
	scale(zoomFactor);// Appliquer le zoom
		
	textFont(font);
	world.gravity.y = 12;

	// PLAYER
	player = new Sprite(-200, 325, 32);
	player.image = spriteImage;
	player.bounciness = 0;
	player.scale = 2;
	player.friction = 0;

	// RENARD
	renard = new Sprite(-200, 325, 64, 64, 's');
	renard.spriteSheet = renardImage;
	renard.bounciness = 0;
	renard.rotationLock = true;
	renard.scale = 2;

	renard.addAnis({
		right: { w: 64, h: 64, row: 0, frames: 4, frameDelay: 16},
	  })
	renard.changeAni("right");

	// LIFE BAR
	lifebar = new Sprite(-200, 325, 148, 68, 'n');
	lifebar.spriteSheet = lifebarImage;
	lifebar.scale = .5;

	lifebar.addAnis({
		stand: {w: 148, h: 68, row: 0, frames: 3, frameDelay: 16},
	  })

	// BOULIER
	bouclier = new Sprite(-200, -500, 48, 48, 'n');
	bouclier.scale = 0;
	bouclier.spriteSheet = bouclierImage;

	bouclier.addAnis({
		damage: { w: 48, h: 48, row: 0, frames: 2, frameDelay: 8},
	})
	bouclier.changeAni("damage");

	// KEYBOARD
	tuto = new Sprite(-200, 325, 200, 125, 's');
	tuto.image = tutoImage;
	tuto.scale = 1;
}

// DEBUT DRAW
function draw() {

	if (state == 0) {
		showMenu();
	}

	else {
	if (life == 0){
		gameOver();
	}

	else{
	clear();
	background(bg_game);

	//if (kb.pressing("a")) {
	//  player.x -= 5;
	//}

	//if (kb.pressing("d")) {
	//	player.x += 5;
	//}

	if (kb.pressing("s")) {
	player.vel.y += 2;
	}

// ------------------------ JUMP ----------------------- //

	if (kb.pressing("space") && isPressed == false) {
		isPressed = true;
		if (jump < 2){
		jump = jump + 1;
		player.vel.y = -7;
		jumpSound.play();
		jumpSound.setVolume(.1);
		}
	}  

	if (kb.released('space')){
		isPressed = false;
	}

// ------------------------ FLOOR ----------------------- //

map = round(map + (0.2*vitesse));

if (map == 48) {
	Pmap = true;
	map = 0;
}

if (map == 1) {
	Pmap = false;
}

if (Pmap == true) {
	if (random(0, 10) < 1){ // GENERATION DE TROU
		VarObstacle = false;
		let floorXL = windowWidth + camera.x ;
		let floorYL = windowHeight -24;
		
		let floorL = new Sprite(floorXL, floorYL, 32, 32, 's');
		floorL.w = 32;
		floorL.h = 32;
		floorL.scale = 1.5;
		floorL.image = sol_3;
		tabFloor.push(floorL);
		

		for (let i = 0; i < 5; i++) {
			let floorX = windowWidth + camera.x ;
			let floorY = windowHeight -24;
			
			let floor = new Sprite((floorX + i * 48), floorY, 32, 32, 'n');
			floor.w = 32;
			floor.h = 32;
			floor.scale = 1.5;
			floor.image = sol_2;
			//floor.debug = true;
		
			tabFloor.push(floor);
		}

		let floorXR = windowWidth + camera.x;
		let floorYR = windowHeight -24;
		
		let floorR = new Sprite((floorXR + 5 * 48), floorYR, 32, 32, 's');
		floorR.w = 32;
		floorR.h = 32;
		floorR.scale = 1.5;
		floorR.image = sol_4;
		tabFloor.push(floorR);
	}
	else { // GENERATION DE SOL
		VarObstacle = true;
		for (let i = 0; i < 6; i++) {
			let floorX = windowWidth + camera.x ;
			let floorY = windowHeight -24; //430
			
			let floor = new Sprite((floorX + i * 48), floorY, 32, 32, 's');
			floor.w = 32;
			floor.h = 32;
			floor.scale = 1.5;
			floor.image = sol_1;
		
			tabFloor.push(floor);
		}
	}
}

for (floor of tabFloor) { // CONDITION SOL
	if (life == 0){
		floor.remove();
	}
	if (player.collide(floor)) {
		jump = 0;
	}
}

//for (floorL of tabFloor) {
//	if (renard.collide(floorL)) {
//		renard.vel.y = -7;
//	}
//}

// ------------------------ OBSTACLES ----------------------- //


	if ( random(0, ent) < 1 && VarObstacle == true){ // GENERATION OBSTACLE
		let obstacleX = windowWidth + camera.x;
		let obstacleY = windowHeight - 62; //430
		
		let obstacle = new Sprite(obstacleX, obstacleY, 32, 32, 'n');
		//obstacle.color = "red";
		obstacle.w = 32;
		obstacle.h = 32;
		obstacle.scale = 1.5;

		if (random(0, 2) < 1) {
			obstacle.image = caillou_2;
		} 
		else {
			obstacle.image = caillou_4;
		}
		tabObstacle.push(obstacle);

		variateur = variateur - 1;
		if (variateur == 0 && ent > 30){ // CONDITION OBSTACLE
			variateur = 5;
			ent = ent - 1;
		}
	}
	
	for (obstacle of tabObstacle) {
		if (player.overlaps(obstacle) && Varlife == true) {
			life = life - 1;
			obstacle.remove();
			Varlife = false;

			breakSound.play();
			breakSound.setVolume(.1);
			shieldSound.play();
			shieldSound.setVolume(.1);
		}	
	}

// ------------------------ OBSTACLES 2 ----------------------- //

if ( random(0, ent_2) < 1){ // GENERATION OISEAU
	let oiseauX = windowWidth + camera.x;
	let oiseauY = windowHeight - random(175,375); //430
	
	let oiseau = new Sprite(oiseauX, oiseauY, 40, 40, 'n');
	oiseau.w = 32;
	oiseau.h = 32;
	oiseau.scale = 1.5;
	oiseau.spriteSheet = oiseauImage;
	//oiseau.debug = true;

	oiseau.addAnis({
		spin: { w: 32, h: 32, row: 0, frames: 5, frameDelay: 8},
	  })
	  oiseau.changeAni("spin");
	
	tabOiseau.push(oiseau);
	variateur_2 = variateur_2 - 1;
	if (variateur_2 == 0 && ent_2 > 8){
		variateur_2 = 5;
		ent_2 = ent_2 - 1;
	}
}

for (oiseau of tabOiseau) { // CONDITION OISEAU
	if (player.overlaps(oiseau) && Varlife == true) {
		life = life - 1;
		oiseau.remove();
		Varlife = false;

		breakSound.play();
		breakSound.setVolume(.1);
		shieldSound.play();
		shieldSound.setVolume(.1);
	}
}

// ------------------------ PIECES ----------------------- //
 
	if (random(0, 70) < 1){ //GENERATION PIECE
		let pieceX = windowWidth + camera.x;
		let pieceY = windowHeight - random(15,300);
		
		let bonus = new Sprite(pieceX, pieceY - 50, 32, 32, 'n');

		bonus.spriteSheet = bonusImage;
		bonus.scale = .8;
		
			bonus.addAnis({
				spin: { w: 32, h: 32, row: 0, frames: 3, frameDelay: 16},
			})
			bonus.changeAni("spin");
			tabPiece.push(bonus);
		}
	
	for (bonus of tabPiece) { // CONDITION PIECE
		if (life == 0){
			bonus.remove();
		}
		if (player.overlaps(bonus)){
			bonus.remove();
			piece += 1;
			coinSound.play();
			coinSound.setVolume(.1);
		}	
	}

// ------------------------ BOUCLIER ----------------------- //

bouclier.x = player.x + 4;
bouclier.y = player.y;

if (Varlife == false){
	console.log("timer");
	timer = timer - 1;

	bouclier.scale = 2;

	if (timer == 0){
		Varlife = true;
		timer = 70;
	}
}
else{
	bouclier.scale = 0;
}

// ------------------------ PARAMETRES ----------------------- //

	// VITESSE
	if (player.x + windowWidth/4 < camera.x) {
		vitessePlayer = vitesse + 1;	
	}
	else if (player.x + windowWidth/4 > camera.x) {
		vitessePlayer = vitesse - 1;
	}
	else{
		vitessePlayer = vitesse;
	}

		if (player.y > windowHeight) {
		life = 0;	
	}

	// VIE
	if(life == 2){
		lifebar.ani.frame = 1;
	}
	else if(life == 1){
		lifebar.ani.frame = 2;
	}
	else{
		lifebar.ani.frame = 0;
	}

	//variateur_vitesse = variateur_vitesse - 1;
	//if (variateur_vitesse == 0 && vitesse < 10){
	//	vitesse = vitesse + 1;
	//	variateur_vitesse = 500;
	//}

	player.x += vitessePlayer;
	player.rotationSpeed = vitesse*2;
	renard.x += vitessePlayer;
	lifebar.x += vitessePlayer;
	tuto.x += vitessePlayer;
	camera.x += vitesse;
	player.vel.x = 0;
	distance = Math.round((camera.x - 250)/ 10);

	lifebar.x = player.x;
	lifebar.y = player.y - 60;


	// ------------------------ TEXT ----------------------- //



	textAlign(CENTER, CENTER);
	textSize(windowWidth/10);
	fill(255, 200);
	stroke(255, 0)
	text(`${piece}`, width/2, height/2 - (windowHeight/4));
}
}
// FIN DRAW
}

// FONCTION PREMIER AFFICHAGE

function load() {
	//FLOOR
	for (let i = 0; i < (windowWidth/16); i++) {
		let floorX = 0 ;
		let floorY = windowHeight - 24; //430
		
		let floor = new Sprite((floorX + i * 32), floorY, 32, 32, 's');
		floor.w = 32;
		floor.h = 32;
		floor.scale = 1.5;
		floor.image = sol_1;
	
		tabFloor.push(floor);
	}
	// OBSTACLES
	for (let i = 0; i < round(windowWidth/320); i++) {
		let obstacleX = camera.x + (i+1 * random((windowWidth/10), (windowWidth/2)));
		let obstacleY = windowHeight - 62;
		
		let obstacle = new Sprite(obstacleX, obstacleY, 32, 32, 'n');
		obstacle.w = 32;
		obstacle.h = 32;
		obstacle.scale = 1.5;
		obstacle.image = caillou_2;
		
		tabObstacle.push(obstacle);
	}
	// OISEAUX
	for (let i = 0; i < round(windowWidth/640); i++) {
		let oiseauX = camera.x + (i+1 * random((windowWidth/10), (windowWidth/2)));
		let oiseauY = windowHeight - random(175,375);
		
		let oiseau = new Sprite(oiseauX, oiseauY, 32, 32, 'n');
		oiseau.w = 32;
		oiseau.h = 32;
		oiseau.scale = 1.5;
		oiseau.spriteSheet = oiseauImage;

		oiseau.addAnis({
			spin: { w: 32, h: 32, row: 0, frames: 5, frameDelay: 8},
		  })
		  oiseau.changeAni("spin");
		
		tabOiseau.push(oiseau);
	}
	// PIECES
	for (let i = 0; i < round(windowWidth/640); i++) {
		let bonusX = camera.x + (i+1 * random((windowWidth/10), (windowWidth/2)));
		let bonusY = windowHeight - random(65,300);
		
		let bonus = new Sprite(bonusX, bonusY, 32, 32, 'n');
		bonus.w = 32;
		bonus.h = 32;
		bonus.scale = .8;
		bonus.spriteSheet = bonusImage;

		bonus.addAnis({
			spin: { w: 32, h: 32, row: 0, frames: 3, frameDelay: 16},
		  })
		bonus.changeAni("spin");
		tabPiece.push(bonus);
	}
}

function showMenu() { // MENU
	clear();
	background(bg_start);
	
	if (kb.pressing("enter")) {
		state = 1;
		player.x = windowWidth/4;
		player.y = windowHeight - 100;
		renard.x = windowWidth/8;
		renard.y = windowHeight - 112;
		tuto.x = windowWidth/5;
		tuto.y = windowHeight/5;

		fondSound.play();
		fondSound.setVolume(0.1);
		load();
	}
}

function gameOver() { // GAME OVER
	player.remove();
	renard.remove();
	lifebar.remove();
	tuto.remove();

	bouclier.remove();
	fondSound.stop();
	shieldSound.stop();
	
	if (debugSound == true) {
		eatSound.play();
		eatSound.setVolume(0.1);
		debugSound = false;
	}

	for (obstacle of tabObstacle) {
		obstacle.remove();
	}
	for (oiseau of tabOiseau) {
		oiseau.remove();
	}
	for (bonus of tabPiece) {
		bonus.remove();
	}
	for (floor of tabFloor) {
		floor.remove();
	}

	background(bg_end);	
	textSize(64);
	fill(0);
	stroke(0, 0);
	textAlign(TOP, CENTER);
	textSize(32);
	text(`Distance : ${distance} mètres`, width/2.1, height/1.09);
	text(`x ${piece}`, width/2.9, height/1.09);

	if (kb.pressing("enter")) {
		window.location.reload();
	  }
  }